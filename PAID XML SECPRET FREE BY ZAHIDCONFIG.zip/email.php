<?php
$emailku = 'zahidahmad0642@gmail.com.';
?>